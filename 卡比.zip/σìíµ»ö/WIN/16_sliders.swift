
//
//  animtion.swift
//  WIN
//
//  Created by User17 on 2020/10/7.
//

import SwiftUI


struct sliders_16: View {
    
    @State private var scale: CGFloat = 1
   
    @State private var pictures: CGFloat = 0
    
    @State private var red1: Double = 0.5
    
    @State private var green1: Double = 1
    
    @State private var blue1: Double = 1
    
    @State private var brightnessAmount: Double = 0
    
 
    
    
    var body: some View {

            NavigationView {
                
            
                VStack {
                   
                    
                    
                    Group
                    {
                        
                        
                        if pictures==0
                        {
                            
                            
                            
                            
                            Image("GG")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:3000, height:  3000))
                        }
                        else if pictures==1
                        {
                            Image("QAQ")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if pictures==2
                        {
                            Image("oao")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))                        }
                        else if pictures==3
                        {
                            Image("卡比")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                            
                        }
                        else if pictures==4
                        {
                            Image("卡比1")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if pictures==5
                        {
                            Image("卡比2")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if pictures==6
                        {
                            Image("卡比3")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if pictures==7
                        {
                            Image("卡比4")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if pictures==8
                        {
                            Image("卡比5")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if pictures==9
                        {
                            Image("卡比6")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                            
                        }
                        else if pictures==10
                        {
                            Image("卡比7")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if pictures==11
                        {
                            Image("卡比8")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                            
                        }
                    }
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    ScrollView{
                             VStack {
                        
                        
                        
                                Text("亮度")
                                
                                Slider(value: $brightnessAmount, in: 0...1, minimumValueLabel: Image(systemName: "sun.max.fill").imageScale(.small), maximumValueLabel: Image(systemName: "sun.max.fill").imageScale(.large))
                        {
                        Text("")
                      }
                       
                    Text("大小: \(scale, specifier: "%.2f")")
                                Slider(value: $scale, in: 0...1, minimumValueLabel: Image(systemName: "sun.max.fill").imageScale(.small), maximumValueLabel: Image(systemName:	 "sun.max.fill").imageScale(.large)) {
                        Text("")
                    }
                        
                    
                    
                    
                     
                   
                            Text("圖片們 第: \(Int(pictures)+1) 張")
                            Slider(value: $pictures, in: 0...11, step: 1)
                                
                                
                                
                                Text("背景顏色: r:\(red1, specifier: "%.1f") g:\(green1, specifier: "%.1f") b:\(blue1, specifier: "%.1f")")
                                Slider(value: $red1, in: 0...1).accentColor(.red)
                                
                                Slider(value: $green1, in: 0...1).accentColor(.green)
                                Slider(value: $blue1, in: 0...1).accentColor(.blue)
                                
                                
                                
                                
                                
                                
                        
                    }//VS
                    }//ScrollView
                    
                    
                    
                    
               
                    
                    
                    
                }
                .padding()
             
 
                }
            

    
        }
}
struct sliders_16_Previews	: PreviewProvider {
    static var previews: some View {
        
            sliders_16()
            
        
    }
}
