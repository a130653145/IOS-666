//
//  ＯＡＯ.swift
//  WIN
//
//  Created by User17 on 2020/10/7.
//

import SwiftUI

struct Scroll_up_down_left_right: View {
    var body: some View {
        
ScrollView{
    Text("上下左右滑")
    ScrollView(.horizontal, showsIndicators: false) {
    HStack(spacing: 20) {
        
    Image("oao")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("卡比")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("QAQ")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
        
        Image("GG")
        .resizable()
        .scaledToFill()
        .frame(width: 200)
        .clipped()
        
    }
    .frame(height: 200)
        
    }
    
 

    
    ScrollView(.horizontal, showsIndicators: false) {
    HStack(spacing: 20) {
        
    Image("oao")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("卡比")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("QAQ")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
        
        Image("GG")
        .resizable()
        .scaledToFill()
        .frame(width: 200)
        .clipped()
        
    }
    .frame(height: 200)
        
    }
    
    
    
    
    ScrollView(.horizontal, showsIndicators: false) {
    HStack(spacing: 20) {
        
    Image("oao")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("卡比")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("QAQ")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
        
        Image("GG")
        .resizable()
        .scaledToFill()
        .frame(width: 200)
        .clipped()
        
    }
    .frame(height: 200)
        
    }
    
    
    
    ScrollView(.horizontal, showsIndicators: false) {
    HStack(spacing: 20) {
        
    Image("oao")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("卡比")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("QAQ")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
        
        Image("GG")
        .resizable()
        .scaledToFill()
        .frame(width: 200)
        .clipped()
        
    }
    .frame(height: 200)
        
    }
    
    
    
    
    ScrollView(.horizontal, showsIndicators: false) {
    HStack(spacing: 20) {
        
    Image("oao")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("卡比")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
    Image("QAQ")
    .resizable()
    .scaledToFill()
    .frame(width: 200)
    .clipped()
        
        Image("GG")
        .resizable()
        .scaledToFill()
        .frame(width: 200)
        .clipped()
        
    }
    .frame(height: 200)
        
    }
    
    
    
    
    

}
.padding(.horizontal, 20)

        
    }
}


struct Scroll_up_down_left_right_Previews: PreviewProvider {
    static var previews: some View {
        Scroll_up_down_left_right()
    }
}
