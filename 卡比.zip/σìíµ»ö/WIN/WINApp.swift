//
//  WINApp.swift
//  WIN
//
//  Created by User17 on 2020/9/25.
//

import SwiftUI

@main
struct WINApp: App {
    var body: some Scene {
        WindowGroup {
            tabview()
        }
    }
}
